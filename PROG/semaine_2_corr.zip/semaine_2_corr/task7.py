""" opérations booléennes
données: deux entiers
résultat: affiche True s'ils sont égaux ou False dans le cas contraire
"""

### déclaration et initilisation de variables
var1: int = 2
var2: int = 3

### séquence d'opérations
is_equal: bool = var1 == var2

print("var1 egal a var2 :", is_equal)
