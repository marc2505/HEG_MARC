""" opérations booléennes
données: deux entiers
résultat: affiche True s'ils sont égaux ou False dans le cas contraire
"""

### déclaration et initilisation de variables
var1: int = 10
var2: int = 5

### séquence d'opérations
is_greater: bool = var1 > var2

print("var1 plus grand que var2 :", is_greater)
