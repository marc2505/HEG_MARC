""" conversion de type
données: les variables number et float_number
résultat: convertir la valeur de la variable float_number en entier
"""

### déclaration et initilisation de variables
number: int = 9
float_number: float = 9.0

### sequence d'opérations

print("type de number :", type(number))   # print type of variable "number"

print("valeur de float_number :", float_number)
print("valeur entier de float_number :", int(float_number))
