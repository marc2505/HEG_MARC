""" variable non définie
données: var1 -> une variable initialisée
résultat: essaye d'afficher une autre variable
"""

### déclaration et initilisation de variables
var1: int = 1

### sequence d'opérations

print("var1 :", var1)
print("nouvelle variable :", test)
