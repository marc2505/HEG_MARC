""" types de variables
données: l'année et deux notes
résultat: affiche les types de variables
"""

### déclaration et initilisation de variables
year: int = 2019
note1: float = 5.0
note2 = 3.0

### sequence d'opérations
print("type de la varialbe year :", type(year))     # affiche le type de la variable "year"
print("type de la varialbe note1 :", type(note1))
print("type de la varialbe note2 :", type(note2))
