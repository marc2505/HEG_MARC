DIST_AUDREY: int = 17

dist_marie: float = 0.0
dist_laura: float = 0.0
dist_max: float = 0.0
dist_jf: float = 0.0

dist_marie = DIST_AUDREY * 2 + 6.75
dist_max = dist_marie - 9.27
dist_laura = dist_max - 7.29
dist_jf = DIST_AUDREY + 8

print(dist_marie)
print(dist_max)
print(dist_laura)
print(DIST_AUDREY)
print(dist_jf)

