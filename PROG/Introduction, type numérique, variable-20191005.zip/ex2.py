masse_geneve = 5000 - (35 * 54.5 + 40 * 35)
masse_lausanne = masse_geneve - 150 * 5
masse_montreux = masse_lausanne - 29 * 12.5

print(masse_geneve)
print(masse_lausanne)
print(masse_montreux)
