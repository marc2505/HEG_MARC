print("Python est très utilisé")
print('Python est très utilisé')

print("C'est facile de programmer en Python")
print('C\'est facile de programmer en Python')

print('Python est fait pour les "nuls"')
print("Python est fait pour les \"nuls\"")

print("""Nous avons vu les types :
    - int
    - float
    - str""")

print('''Nous avons vu les types :
    - int
    - float
    - str''')

print("Nous avons vu les types :\n\t"
      "- int\n\t- float\n\t- str")
















print("Nous avons vu les types :")
print("\t- int")
print("\t- float")
print("\t- str")
