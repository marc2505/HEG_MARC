"""
2.1 Ecrire un algorithme qui affiche le prix de n photocopies sachant que le reprographe facture
CHF -.10 les dix premières photocopies,
CHF -.09 les vingt suivantes et
CHF -.08 au-delà

Exemples de déroulement :

Entrer le nombre de photocopies ?
Le prix est :   CHF xxx.xx
"""
