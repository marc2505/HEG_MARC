"""
2.2  Ecrire un algorithme qui affiche si un contribuable d’un pays imaginaire est imposable ou non sachant que :
- les hommes de plus de 18 ans paient l’impôt
- les femmes paient l’impôt si elles ont entre 18 et 35 ans
- les autres ne paient pas d’impôt

Exemples de déroulement :

Ex.: 1
... <saisir les données> ...
"Vous êtes imposable !"


Ex.: 2
... <saisir les données> ...
"Vous n'êtes pas imposable !"
"""
